#!/usr/bin/env python3
"""Slice a grid sprite sheet into fixed-size frames without redrawing the art.

Outputs (in --out):
  <name>_spritesheet_<F>.png   clean N x M sheet of F x F frames
  <name>_spritesheet_<F>.json  frame size + animation -> frame indices
  <name>_frames_<F>.zip        every frame as its own PNG
  <name>_spriteframes.tres     Godot 4 SpriteFrames resource (with --godot)
  <name>_preview.html          looping preview of every animation

Example:
  python slice_spritesheet.py owl.png --name owl --grid 8x8 --frame 128 \
    --anim egg_idle=1 --anim egg_hatch=2 --anim owl_emerge=3 --anim owl_idle=4 \
    --anim jump_land=5-6 --anim ticklish_recovery=7-8 --fps 10 --godot
"""
import argparse, base64, io, json, os, zipfile
from PIL import Image


def parse_rows(spec):
    rows = []
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-")
            rows += list(range(int(a), int(b) + 1))
        else:
            rows.append(int(part))
    return [r - 1 for r in rows]  # 1-based in, 0-based out


def main():
    p = argparse.ArgumentParser()
    p.add_argument("image")
    p.add_argument("--name", required=True, help="asset name prefix, e.g. owl")
    p.add_argument("--grid", default="8x8", help="COLSxROWS of the source grid")
    p.add_argument("--frame", type=int, default=128, help="output frame size in px")
    p.add_argument("--anim", action="append", default=[],
                   help="name=rows (1-based, e.g. idle=4 or jump=5-6). Repeatable.")
    p.add_argument("--fps", type=float, default=10)
    p.add_argument("--clean-alpha", type=int, default=0,
                   help="zero out pixels with alpha below this (removes faint colored fringes). 0 = keep art untouched")
    p.add_argument("--nearest", action="store_true",
                   help="use nearest-neighbour scaling (true pixel art); default Lanczos")
    p.add_argument("--godot", action="store_true", help="also write a Godot 4 SpriteFrames .tres")
    p.add_argument("--res-dir", default="res://",
                   help="Godot folder the sheet PNG will live in, e.g. res://assets/pets/owl/")
    p.add_argument("--out", default=".")
    a = p.parse_args()

    cols, rows = (int(x) for x in a.grid.lower().split("x"))
    F = a.frame
    os.makedirs(a.out, exist_ok=True)
    src = Image.open(a.image).convert("RGBA")
    W, H = src.size
    xb = [round(i * W / cols) for i in range(cols + 1)]
    yb = [round(i * H / rows) for i in range(rows + 1)]
    scaled = (xb[1] - xb[0]) != F or (yb[1] - yb[0]) != F
    resample = Image.NEAREST if a.nearest else Image.LANCZOS

    anims = {}
    for spec in a.anim:
        n, r = spec.split("=")
        anims[n] = parse_rows(r)
    if not anims:
        anims = {f"row_{r + 1}": [r] for r in range(rows)}
    row_label = {}
    for n, rs in anims.items():
        for i, r in enumerate(rs):
            row_label.setdefault(r, n if len(rs) == 1 else f"{n}_{chr(97 + i)}")

    sheet = Image.new("RGBA", (F * cols, F * rows), (0, 0, 0, 0))
    zbuf = io.BytesIO()
    with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as z:
        for r in range(rows):
            for c in range(cols):
                cell = src.crop((xb[c], yb[r], xb[c + 1], yb[r + 1]))
                if scaled:  # premultiplied resize avoids halo bleed
                    cell = cell.convert("RGBa").resize((F, F), resample).convert("RGBA")
                if a.clean_alpha:
                    px = cell.load()
                    for y in range(F):
                        for x in range(F):
                            if px[x, y][3] < a.clean_alpha:
                                px[x, y] = (0, 0, 0, 0)
                sheet.paste(cell, (c * F, r * F))
                b = io.BytesIO(); cell.save(b, "PNG")
                z.writestr(f"frames/{row_label.get(r, f'row_{r + 1}')}_{c:02d}.png", b.getvalue())

    base = f"{a.name}_spritesheet_{F}"
    sheet_path = os.path.join(a.out, base + ".png")
    sheet.save(sheet_path, optimize=True)
    with open(os.path.join(a.out, f"{a.name}_frames_{F}.zip"), "wb") as f:
        f.write(zbuf.getvalue())

    meta = {"image": base + ".png", "frameWidth": F, "frameHeight": F,
            "columns": cols, "rows": rows, "fps": a.fps,
            "animations": {n: [r * cols + c for r in rs for c in range(cols)] for n, rs in anims.items()}}
    with open(os.path.join(a.out, base + ".json"), "w") as f:
        json.dump(meta, f, indent=1)

    if a.godot:
        write_godot(os.path.join(a.out, f"{a.name}_spriteframes.tres"), a.res_dir.rstrip("/") + "/" + base + ".png", F, cols, meta, a.fps)
    write_preview(os.path.join(a.out, f"{a.name}_preview.html"), sheet_path, a.name, F, cols, rows, anims, a.fps)

    print(f"source {W}x{H}, cell ~{W / cols:.1f}px -> {F}px ({'scaled' if scaled else 'exact, no scaling'})")
    print("wrote", sorted(os.listdir(a.out)))


def write_godot(path, png, F, cols, meta, fps):
    frames = sorted({i for v in meta["animations"].values() for i in v})
    lines = [f'[gd_resource type="SpriteFrames" load_steps={len(frames) + 2} format=3]', "",
             f'[ext_resource type="Texture2D" path="{png}" id="1"]', ""]
    for i in frames:
        lines += [f'[sub_resource type="AtlasTexture" id="f{i}"]', 'atlas = ExtResource("1")',
                  f"region = Rect2({(i % cols) * F}, {(i // cols) * F}, {F}, {F})", ""]
    anims = []
    for n, idx in meta["animations"].items():
        fr = ", ".join('{"duration": 1.0, "texture": SubResource("f%d")}' % i for i in idx)
        anims.append('{"frames": [%s], "loop": true, "name": &"%s", "speed": %s}' % (fr, n, float(fps)))
    lines += ["[resource]", "animations = [" + ", ".join(anims) + "]", ""]
    with open(path, "w") as f:
        f.write("\n".join(lines))


def write_preview(path, sheet_path, name, F, cols, rows, anims, fps):
    data = base64.b64encode(open(sheet_path, "rb").read()).decode()
    css, cards = [], []
    for k, (n, rs) in enumerate(anims.items()):
        seg = 100 / len(rs)
        kf = []
        for i, r in enumerate(rs):
            s, e = i * seg, (i + 1) * seg - 0.001
            kf.append(f"{s:.3f}%{{background-position:0 -{r * F}px;animation-timing-function:steps({cols},end)}}")
            kf.append(f"{e:.3f}%{{background-position:-{cols * F}px -{r * F}px}}")
        css.append(f"@keyframes a{k}{{{''.join(kf)}}}.a{k}{{animation:a{k} {len(rs) * cols / fps}s infinite}}")
        label = f"row {rs[0] + 1}" if len(rs) == 1 else f"rows {rs[0] + 1}-{rs[-1] + 1}"
        cards.append(f'<figure><div class="chk"><div class="spr a{k}"></div></div><figcaption>{n}<small>{label}</small></figcaption></figure>')
    html = f"""<!doctype html><meta charset=utf-8><title>{name} sprites</title><style>
body{{margin:0;padding:32px;font-family:Georgia,serif;background:#f4efe6;color:#2b2118}}
.grid{{display:flex;flex-wrap:wrap;gap:20px}}figure{{margin:0;padding:16px;background:#fffaf2;border:1px solid #ddd0bb;border-radius:12px;text-align:center}}
figcaption{{margin-top:8px;font-weight:600}}small{{display:block;font:12px monospace;color:#5c4a3a}}
.chk{{width:{F}px;height:{F}px;background:repeating-conic-gradient(#ddd3c2 0 25%,#e9e2d5 0 50%) 0 0/16px 16px}}
.spr{{width:{F}px;height:{F}px;background:url(data:image/png;base64,{data}) no-repeat;background-size:{cols * F}px {rows * F}px}}
{''.join(css)}</style><h1>{name} · {F}px frames · {fps:g} fps</h1><div class=grid>{''.join(cards)}</div>"""
    with open(path, "w") as f:
        f.write(html)


if __name__ == "__main__":
    main()
