---
name: sprite-sheet-slicer
description: Cut a grid sprite sheet (e.g. an 8x8 pet animation sheet) into fixed-size frames such as 128x128 without redrawing the art, and export a clean sheet, per-frame PNGs, animation JSON, a Godot SpriteFrames resource and a looping preview. Use when asked to slice, cut, split or animate a sprite sheet for Project P.
---

# Sprite sheet slicer

Turns a generated sprite sheet (usually 8x8 cells, one animation per row or pair of rows) into game-ready frames. The art is **cropped and scaled only — never redrawn, repainted or regenerated**.

## Inputs to collect

1. The sheet image (attached file).
2. Grid layout — default `8x8`.
3. Output frame size — default `128` px.
4. Row → animation mapping. The standard Project P pet layout is:

   | Rows | Animation | `--anim` flag |
   | --- | --- | --- |
   | 1 | Egg idle | `egg_idle=1` |
   | 2 | Egg hatch | `egg_hatch=2` |
   | 3 | Pet emerging | `<pet>_emerge=3` |
   | 4 | Pet idle | `<pet>_idle=4` |
   | 5–6 | Jump and landing | `jump_land=5-6` |
   | 7–8 | Ticklish and recovery | `ticklish_recovery=7-8` |

   Rows read left to right, 1-based. If the user gives a different mapping, use theirs. If they give none and the sheet looks like the standard layout, use the table above and say so.
5. Pet name (used as file prefix, e.g. `owl`, `turtle`).

## Run

```bash
pip install pillow --break-system-packages   # if Pillow is missing
python claude-skills/sprite-sheet-slicer/scripts/slice_spritesheet.py <sheet.png> \
  --name owl --grid 8x8 --frame 128 \
  --anim egg_idle=1 --anim egg_hatch=2 --anim owl_emerge=3 --anim owl_idle=4 \
  --anim jump_land=5-6 --anim ticklish_recovery=7-8 \
  --fps 10 --godot --res-dir res://assets/pets/owl --out out/owl
```

Options:

- `--fps` playback speed written to the JSON, Godot resource and preview (default 10).
- `--godot` also writes `<name>_spriteframes.tres` (Godot 4 `SpriteFrames`, one looping animation per `--anim`). `--res-dir` is the Godot folder the sheet PNG will be placed in.
- `--clean-alpha N` zeroes pixels with alpha below N. Off by default so the art stays untouched; suggest `--clean-alpha 16` when faint red/yellow fringes from AI background removal show up in-game.
- `--nearest` uses nearest-neighbour scaling for true pixel art; default is Lanczos (premultiplied alpha, so edges don't bleed).

## Outputs

| File | Contents |
| --- | --- |
| `<name>_spritesheet_<F>.png` | Clean sheet, `cols*F` x `rows*F`, same order as the source |
| `<name>_spritesheet_<F>.json` | Frame size, grid, fps, animation name → frame indices |
| `<name>_frames_<F>.zip` | Every frame as `<animation>_<col>.png` (two-row animations get `_a` / `_b`) |
| `<name>_spriteframes.tres` | Godot SpriteFrames (with `--godot`) |
| `<name>_preview.html` | Self-contained page looping each animation on a transparency checkerboard |

Hand the user the sheet, JSON and zip (plus `.tres` when they use Godot) and show the preview. If a Design canvas is open, add one artboard per pet showing the full sheet and one looping player per animation, using the uploaded sheet as a CSS `steps(<cols>)` background animation.

## Things to tell the user

- The script prints the source cell size. If it isn't exactly the frame size (e.g. a 1254 px sheet → ~157 px cells), frames were **scaled** to fit — slightly softer, not redrawn. For pixel-exact frames, export the source at `cols * F` px (1024 px for 8x8 @ 128).
- Mention any visible colored fringe and offer `--clean-alpha` rather than applying it silently.
- Cell boundaries use `round(i * width / cols)`, so non-integer cell sizes are handled without drift.
